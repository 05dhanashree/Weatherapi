
let temp = document.querySelector("#temp");
let humidity = document.querySelector("#humidity");
let windspeed = document.querySelector("#windspeed");
let icon = document.querySelector("#icon");
let value = document.querySelector("#value");
let city = document.querySelector("#city");
let details = document.querySelector("#details");
let weatherimage = document.querySelector("#weatherimage");
let description = document.querySelector("#description");

 async function search(){
    try{
    let cityname = document.getElementById('cityname').value;
    
    
   let results = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cityname}&appid=222076a1aa8b61de179491e4debcd549&units=metric`);
   let data = await results.json();
    console.log(data);
    
    details.innerHTML = "Weather in "+ data.name;   
    temp.innerHTML = "Temperature: " + data.main.temp + "°C";
    weatherimage.src =`https://openweathermap.org/img/wn/${data.weather[0].icon}.png`;
    description.innerHTML = data.weather[0].description;
    humidity.innerHTML = "Humidity: " + data.main.humidity + "%";
    windspeed.innerHTML = "Wind Speed: " + data.wind.speed + "km/h";
    

    
 }
 catch(error){
    alert("city not found so please try again");
    return false;
 }
}

 

 

// async function getData() {
//     try{
//     let url ="https://api.openweathermap.org/data/2.5/weather?q={city name}&appid=222076a1aa8b61de179491e4debcd549&units=metric"
//     //let url = "https://api.openweathermap.org/data/2.5/weather?q=pune&appid=222076a1aa8b61de179491e4debcd549&units=metric";
//     let response = await fetch(url); //to communicate with server and to run fetch response we use await because fetch is promise and we dont want to use then catch
//     let data = await response.json();
//     console.log(data);
//     cityname.innerHTML = data.name;
//     } catch(error) {
//         console.log(error);
//     }
// }
// getData();